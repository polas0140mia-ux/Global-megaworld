# identity

Sign-up, login, sessions, roles (buyer, seller, freelancer, admin) and KYC hooks.

Status: not started. Write these tests first, in this order:

- rejects weak passwords and duplicate emails
- stores only a salted hash, never the password
- locks the account after repeated failed logins
- issues short-lived access tokens and rotates refresh tokens
- a user can never read or change another user's data
