export type AccountId = string;

export interface Leg {
  from: AccountId;
  to: AccountId;
  /** Minor units (cents, paisa...). Always a positive integer, never a float. */
  amount: number;
  /** ISO 4217 code, for example "USD". */
  currency: string;
}

export interface Transaction {
  readonly id: string;
  readonly idempotencyKey: string;
  readonly legs: readonly Readonly<Leg>[];
  readonly createdAt: string;
}

export interface PostInput {
  idempotencyKey: string;
  legs: readonly Leg[];
}

/** Time and ids are injected so tests are deterministic. */
export interface LedgerDeps {
  clock: { now(): Date };
  newId: () => string;
}

export type LedgerErrorCode =
  | "INVALID_INPUT"
  | "INVALID_AMOUNT"
  | "INSUFFICIENT_FUNDS"
  | "IDEMPOTENCY_CONFLICT";

export class LedgerError extends Error {
  readonly code: LedgerErrorCode;

  constructor(code: LedgerErrorCode, message: string) {
    super(message);
    this.name = "LedgerError";
    this.code = code;
  }
}

/** System accounts (for example the payment provider) may go negative; user and escrow accounts may not. */
export function isSystemAccount(account: AccountId): boolean {
  return account.startsWith("system:");
}

const CURRENCY = /^[A-Z]{3}$/;

function validate(leg: Leg): void {
  if (!leg.from || !leg.to || leg.from === leg.to) {
    throw new LedgerError("INVALID_INPUT", "A leg needs two different accounts");
  }
  if (!CURRENCY.test(leg.currency)) {
    throw new LedgerError("INVALID_INPUT", `Bad currency code: ${leg.currency}`);
  }
  if (!Number.isSafeInteger(leg.amount) || leg.amount <= 0) {
    throw new LedgerError("INVALID_AMOUNT", "Amount must be a positive integer in minor units");
  }
}

function fingerprint(legs: readonly Leg[]): string {
  return legs.map((l) => `${l.from}>${l.to}:${l.amount}${l.currency}`).join(";");
}

function slot(account: AccountId, currency: string): string {
  return `${account}|${currency}`;
}

/**
 * In-memory ledger. Every transaction moves money between accounts, so the
 * books always balance. Transactions are all-or-nothing and idempotent.
 */
export class Ledger {
  private readonly deps: LedgerDeps;
  private balances = new Map<string, number>();
  private readonly log: Transaction[] = [];
  private readonly seen = new Map<string, { fingerprint: string; tx: Transaction }>();

  constructor(deps: LedgerDeps) {
    this.deps = deps;
  }

  post(input: PostInput): Transaction {
    const { idempotencyKey, legs } = input;
    if (!idempotencyKey) {
      throw new LedgerError("INVALID_INPUT", "idempotencyKey is required");
    }

    const print = fingerprint(legs);
    const prior = this.seen.get(idempotencyKey);
    if (prior) {
      if (prior.fingerprint !== print) {
        throw new LedgerError("IDEMPOTENCY_CONFLICT", "Key already used with a different payload");
      }
      return prior.tx;
    }

    if (legs.length === 0) {
      throw new LedgerError("INVALID_INPUT", "At least one leg is required");
    }
    legs.forEach(validate);

    // Work on a copy so a failing leg leaves the real balances untouched.
    const next = new Map(this.balances);
    for (const leg of legs) {
      const fromKey = slot(leg.from, leg.currency);
      const toKey = slot(leg.to, leg.currency);
      const remaining = (next.get(fromKey) ?? 0) - leg.amount;
      if (remaining < 0 && !isSystemAccount(leg.from)) {
        throw new LedgerError("INSUFFICIENT_FUNDS", `${leg.from} has too little ${leg.currency}`);
      }
      next.set(fromKey, remaining);
      next.set(toKey, (next.get(toKey) ?? 0) + leg.amount);
    }

    const tx: Transaction = Object.freeze({
      id: this.deps.newId(),
      idempotencyKey,
      legs: Object.freeze(legs.map((l) => Object.freeze({ ...l }))),
      createdAt: this.deps.clock.now().toISOString(),
    });
    this.balances = next;
    this.log.push(tx);
    this.seen.set(idempotencyKey, { fingerprint: print, tx });
    return tx;
  }

  balance(account: AccountId, currency: string): number {
    return this.balances.get(slot(account, currency)) ?? 0;
  }

  /** Sum of every account in one currency. Always 0: money is moved, never created. */
  trialBalance(currency: string): number {
    let sum = 0;
    for (const [key, value] of this.balances) {
      if (key.endsWith(`|${currency}`)) sum += value;
    }
    return sum;
  }

  history(): readonly Transaction[] {
    return [...this.log];
  }
}
