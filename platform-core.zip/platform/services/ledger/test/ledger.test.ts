import { describe, test } from "node:test";
import assert from "node:assert/strict";
import { Ledger, LedgerError } from "../src/ledger.ts";
import { fixedClock, sequentialIds } from "../../../packages/test-kit/src/index.ts";

function setup() {
  const clock = fixedClock();
  const ledger = new Ledger({ clock, newId: sequentialIds("tx") });
  return { ledger, clock };
}

/** Money arriving from the payment provider into a user account. */
function fund(ledger: Ledger, account: string, amount: number, currency = "USD") {
  return ledger.post({
    idempotencyKey: `fund-${account}-${amount}-${currency}`,
    legs: [{ from: "system:psp", to: account, amount, currency }],
  });
}

function expectError(fn: () => unknown, code: string) {
  assert.throws(fn, (err: unknown) => err instanceof LedgerError && err.code === code);
}

describe("Ledger", () => {
  test("moves money and keeps the books balanced", () => {
    const { ledger } = setup();
    fund(ledger, "wallet:buyer", 5000);
    ledger.post({
      idempotencyKey: "pay-1",
      legs: [{ from: "wallet:buyer", to: "wallet:seller", amount: 1200, currency: "USD" }],
    });
    assert.equal(ledger.balance("wallet:buyer", "USD"), 3800);
    assert.equal(ledger.balance("wallet:seller", "USD"), 1200);
    assert.equal(ledger.trialBalance("USD"), 0);
  });

  test("rejects zero, negative, fractional and non-finite amounts", () => {
    const { ledger } = setup();
    [0, -5, 0.1 + 0.2, NaN, Infinity].forEach((amount, i) => {
      expectError(
        () =>
          ledger.post({
            idempotencyKey: `bad-${i}`,
            legs: [{ from: "system:psp", to: "wallet:a", amount, currency: "USD" }],
          }),
        "INVALID_AMOUNT",
      );
    });
    assert.equal(ledger.history().length, 0);
  });

  test("rejects malformed requests", () => {
    const { ledger } = setup();
    const ok = { from: "system:psp", to: "wallet:a", amount: 100, currency: "USD" };
    expectError(() => ledger.post({ idempotencyKey: "", legs: [ok] }), "INVALID_INPUT");
    expectError(() => ledger.post({ idempotencyKey: "k1", legs: [] }), "INVALID_INPUT");
    expectError(() => ledger.post({ idempotencyKey: "k2", legs: [{ ...ok, to: ok.from }] }), "INVALID_INPUT");
    expectError(() => ledger.post({ idempotencyKey: "k3", legs: [{ ...ok, currency: "usd" }] }), "INVALID_INPUT");
  });

  test("blocks overdraft on user wallets and leaves balances unchanged", () => {
    const { ledger } = setup();
    fund(ledger, "wallet:buyer", 1000);
    expectError(
      () =>
        ledger.post({
          idempotencyKey: "too-much",
          legs: [{ from: "wallet:buyer", to: "wallet:seller", amount: 1001, currency: "USD" }],
        }),
      "INSUFFICIENT_FUNDS",
    );
    assert.equal(ledger.balance("wallet:buyer", "USD"), 1000);
    assert.equal(ledger.balance("wallet:seller", "USD"), 0);
  });

  test("lets system accounts go negative (money arriving from the PSP)", () => {
    const { ledger } = setup();
    fund(ledger, "wallet:buyer", 5000);
    assert.equal(ledger.balance("system:psp", "USD"), -5000);
    assert.equal(ledger.trialBalance("USD"), 0);
  });

  test("is idempotent: replaying a key returns the same transaction and moves money once", () => {
    const { ledger } = setup();
    fund(ledger, "wallet:buyer", 5000);
    const legs = [{ from: "wallet:buyer", to: "wallet:seller", amount: 700, currency: "USD" }];
    const first = ledger.post({ idempotencyKey: "pay-2", legs });
    const replay = ledger.post({ idempotencyKey: "pay-2", legs });
    assert.equal(replay.id, first.id);
    assert.equal(ledger.balance("wallet:seller", "USD"), 700);
    assert.equal(ledger.history().length, 2);
  });

  test("rejects the same idempotency key with a different payload", () => {
    const { ledger } = setup();
    fund(ledger, "wallet:buyer", 5000);
    ledger.post({
      idempotencyKey: "pay-3",
      legs: [{ from: "wallet:buyer", to: "wallet:seller", amount: 700, currency: "USD" }],
    });
    expectError(
      () =>
        ledger.post({
          idempotencyKey: "pay-3",
          legs: [{ from: "wallet:buyer", to: "wallet:seller", amount: 800, currency: "USD" }],
        }),
      "IDEMPOTENCY_CONFLICT",
    );
  });

  test("keeps currencies separate", () => {
    const { ledger } = setup();
    fund(ledger, "wallet:buyer", 1000, "USD");
    expectError(
      () =>
        ledger.post({
          idempotencyKey: "eur-pay",
          legs: [{ from: "wallet:buyer", to: "wallet:seller", amount: 500, currency: "EUR" }],
        }),
      "INSUFFICIENT_FUNDS",
    );
    assert.equal(ledger.balance("wallet:buyer", "USD"), 1000);
    assert.equal(ledger.balance("wallet:buyer", "EUR"), 0);
  });

  test("is all-or-nothing: a failing leg rolls back the whole transaction", () => {
    const { ledger } = setup();
    fund(ledger, "wallet:buyer", 1000);
    expectError(
      () =>
        ledger.post({
          idempotencyKey: "two-legs",
          legs: [
            { from: "wallet:buyer", to: "wallet:seller", amount: 600, currency: "USD" },
            { from: "wallet:buyer", to: "wallet:seller", amount: 600, currency: "USD" },
          ],
        }),
      "INSUFFICIENT_FUNDS",
    );
    assert.equal(ledger.balance("wallet:buyer", "USD"), 1000);
    assert.equal(ledger.balance("wallet:seller", "USD"), 0);
  });

  test("escrow: hold, then release splits seller payout and platform fee in one transaction", () => {
    const { ledger } = setup();
    fund(ledger, "wallet:buyer", 10000);

    ledger.post({
      idempotencyKey: "order-7-hold",
      legs: [{ from: "wallet:buyer", to: "escrow:order-7", amount: 10000, currency: "USD" }],
    });
    assert.equal(ledger.balance("escrow:order-7", "USD"), 10000);
    assert.equal(ledger.balance("wallet:buyer", "USD"), 0);

    ledger.post({
      idempotencyKey: "order-7-release",
      legs: [
        { from: "escrow:order-7", to: "wallet:seller", amount: 9000, currency: "USD" },
        { from: "escrow:order-7", to: "system:platform-fees", amount: 1000, currency: "USD" },
      ],
    });
    assert.equal(ledger.balance("escrow:order-7", "USD"), 0);
    assert.equal(ledger.balance("wallet:seller", "USD"), 9000);
    assert.equal(ledger.balance("system:platform-fees", "USD"), 1000);
    assert.equal(ledger.trialBalance("USD"), 0);

    expectError(
      () =>
        ledger.post({
          idempotencyKey: "order-7-release-again",
          legs: [{ from: "escrow:order-7", to: "wallet:seller", amount: 1, currency: "USD" }],
        }),
      "INSUFFICIENT_FUNDS",
    );
  });

  test("transactions are immutable and stamped by the injected clock and ids", () => {
    const { ledger, clock } = setup();
    const a = fund(ledger, "wallet:a", 100);
    clock.advance(5000);
    const b = fund(ledger, "wallet:b", 100);

    assert.equal(a.id, "tx_0001");
    assert.equal(a.createdAt, "2026-01-01T00:00:00.000Z");
    assert.equal(b.createdAt, "2026-01-01T00:00:05.000Z");
    assert.ok(Object.isFrozen(a));
    assert.ok(Object.isFrozen(a.legs));
    assert.throws(() => {
      (a.legs[0] as { amount: number }).amount = 1;
    }, TypeError);
  });
});
