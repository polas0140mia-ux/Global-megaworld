# notification

Email, SMS and push, triggered by events such as `ledger.transaction_posted`.

Status: not started. Write these tests first, in this order:

- one event produces exactly one message, even if the event is delivered twice
- respects the user's channel and language preferences
- retries with backoff, then moves the message to a dead-letter queue
- every template renders in each supported language
