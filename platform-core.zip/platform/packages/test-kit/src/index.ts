// Shared test helpers. Production code must never import from here.

export function fixedClock(iso = "2026-01-01T00:00:00.000Z") {
  let t = new Date(iso).getTime();
  return {
    now: () => new Date(t),
    advance: (ms: number) => {
      t += ms;
    },
  };
}

export function sequentialIds(prefix = "id") {
  let n = 0;
  return () => `${prefix}_${String(++n).padStart(4, "0")}`;
}
