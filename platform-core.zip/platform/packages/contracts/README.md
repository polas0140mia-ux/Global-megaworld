# contracts

Event and API schemas shared between services.

Every producer and consumer pair gets a contract test here before it ships.
First contract to write: `ledger.transaction_posted` (id, idempotencyKey, legs, createdAt).
