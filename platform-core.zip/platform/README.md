# Platform

Shared core first, vertical adapters later, tests before features.

## Layout

```
services/
  ledger/         money movement, escrow, idempotency   (done: first unit)
  identity/       sign-up, login, roles, KYC hooks      (next)
  notification/   email, SMS, push                      (after identity)
packages/
  test-kit/       shared fakes: fixed clock, sequential ids
                  (add: fake payment provider, supplier API, media processor)
  contracts/      event and API schemas, contract tests
tests/
  integration/  e2e/  security/  perf/                  (empty until a service needs them)
.github/workflows/ci.yml
```

## Run

Node 22.18 or newer runs the TypeScript directly, with no build step.

```
npm test                          # unit tests, zero dependencies
npm install && npm run typecheck  # type check (needs typescript and @types/node)
```

## Rules

1. No service is done without unit tests for its business rules.
2. Production code never imports test-kit. Time and ids are injected, so tests are deterministic.
3. Money is always integer minor units plus a currency code. Never floats.
4. Every money-moving call carries an idempotency key.
5. Events and cross-service calls get a contract test in packages/contracts before they ship.
6. Later, every vertical adapter must pass the engine's conformance tests before it merges.
